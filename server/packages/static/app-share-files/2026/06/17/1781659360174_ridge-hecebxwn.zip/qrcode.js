export default {
  name: "QR",
  state: {
    text: "",
    qrValue: ""
  },
  computed: {},
  setup() {
    console.log("QRCode 页面已初始化");
  },
  actions: {
    generate() {
      if (!this.state.text) {
        this.state.qrValue = "https://ant.design";
      } else {
        this.state.qrValue = this.state.text;
      }
    },
    download() {
      const canvas = document.querySelector("canvas");
      if (!canvas) return;

      const url = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = url;
      a.download = "qrcode.png";
      a.click();
    }
  }
};