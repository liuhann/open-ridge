export default {
    "name": "textStatistics",
    "state": {
        "inputText": "",
        "charCount": 0,
        "chineseCharCount": 0,
        "charCountWithoutNewLine": 0,
        "charCountWithoutSpaceAndNewLine": 0,
        "lineCount": 0,
        "nonEmptyLineCount": 0,
        "byteCount": 0
    },
    "setup": function () {
        this.updateStatistics();
    },
    "actions": {
        "updateInputText": function () {
            this.updateStatistics();
        },
        "formatText": function () {
            let lines = this.state.inputText.split('\n');
            let indentedLines = lines.map(line => '    '.concat(line));
            this.state.inputText = indentedLines.join('\n');
            this.updateStatistics();
        },
        "updateStatistics": function () {
            const text = this.state.inputText;
            this.state.charCount = text.length;
            this.state.chineseCharCount = text.replace(/[^\u4e00-\u9fff]/g, '').length;
            this.state.charCountWithoutNewLine = text.replace(/\n/g, '').length;
            this.state.charCountWithoutSpaceAndNewLine = text.replace(/[\s\n]/g, '').length;
            this.state.lineCount = text.split('\n').length;
            this.state.nonEmptyLineCount = text.split('\n').filter(line => line.trim()!== '').length;
            const encoder = new TextEncoder();
            this.state.byteCount = encoder.encode(text).length;
        }
    }
}