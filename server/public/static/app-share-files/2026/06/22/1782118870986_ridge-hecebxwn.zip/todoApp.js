export default {
    "name": "todoApp",
    "state": {
        "newTodoText": "",
        "newTodoDate": "",
        "todoList": [],
        "showEmptyCard": true
    },
    "setup": function () {
        if (this.state.todoList.length === 0) {
            this.state.showEmptyCard = true;
        } else {
            this.state.showEmptyCard = false;
        }
    },
    "actions": {
        "updateNewTodoText": function () {
            this.state.newTodoText = this.state.newTodoText;
        },
        "updateNewTodoDate": function () {
            this.state.newTodoDate = this.state.newTodoDate;
        },
        "addTodo": function () {
            if (this.state.newTodoText && this.state.newTodoDate) {
                const newTodo = {
                    title: this.state.newTodoText,
                    desc: this.state.newTodoDate,
                    tags: [
                        {
                            label: '未完成',
                            theme: 'warning'
                        }
                    ]
                };
                this.state.todoList.push(newTodo);
                this.state.newTodoText = "";
                this.state.newTodoDate = "";
                this.state.showEmptyCard = false;
            }
        },
        "toggleTodoCompletion": function (index, checked) {
            const newList = [...this.state.todoList];
            if (checked) {
                newList[index].tags = [
                    {
                        label: '已完成',
                        theme:'success'
                    }
                ];
            } else {
                newList[index].tags = [
                    {
                        label: '未完成',
                        theme: 'warning'
                    }
                ];
            }
            this.state.todoList = newList;
        },
        "deleteTodo": function (index) {
            const newList = [...this.state.todoList];
            newList.splice(index, 1);
            this.state.todoList = newList;
            if (this.state.todoList.length === 0) {
                this.state.showEmptyCard = true;
            }
        },
        "closeEmptyCard": function () {
            this.state.showEmptyCard = false;
        }
    }
};