export default {
  name: "todo",

  state: {
    inputText: "",
    inputDate: "",
    list: []
  },

  setup() {
    // 初始化示例数据（可选）
    this.state.list = [
      {
        title: "完成 Open-Ridge 文档",
        desc: "2026-06-25",
        theme: "primary",
        tags: [{ label: "未完成", theme: "warning" }],
        menus: ["删除"]
      }
    ];
  },

  actions: {
    addTodo() {
      const { inputText, inputDate, list } = this.state;

      if (!inputText) return;

      list.push({
        title: inputText,
        desc: inputDate || "无计划日期",
        theme: "primary",
        tags: [{ label: "未完成", theme: "warning" }],
        menus: ["删除"]
      });

      this.state.inputText = "";
      this.state.inputDate = "";
    },

    toggleStatus(index) {
      const item = this.state.list[index];
      if (!item) return;

      const done = item.tags[0]?.label === "已完成";

      item.tags = done
        ? [{ label: "未完成", theme: "warning" }]
        : [{ label: "已完成", theme: "success" }];
    },

    onMenuClick(rowIndex, menuKey) {
      if (menuKey === "删除") {
        this.state.list.splice(rowIndex, 1);
      }
    }
  }
}