export default {
  "name": "areaConvert",
  "state": {
    // 静态文本
    title: "面积单位转换器",
    desc: "输入面积数值并选择源单位，自动转换为所有常用面积单位",
    resultTitle: "转换结果",
    // 核心交互状态
    inputValue: 0,
    sourceUnit: "squareMeter",
    // 单位选项（Select组件用）
    unitOptions: [
      { label: "平方米", value: "squareMeter" },
      { label: "亩", value: "mu" },
      { label: "公顷", value: "hectare" },
      { label: "平方千米", value: "squareKilometer" },
      { label: "平方分米", value: "squareDecimeter" },
      { label: "平方厘米", value: "squareCentimeter" },
      { label: "平方毫米", value: "squareMillimeter" },
      { label: "英亩", value: "acre" },
      { label: "平方英尺", value: "squareFoot" },
      { label: "平方英寸", value: "squareInch" }
    ],
    // 面积换算系数（基准：1单位=平方米）
    unitRate: {
      squareMeter: 1,
      mu: 666.6666667,
      hectare: 10000,
      squareKilometer: 1000000,
      squareDecimeter: 0.01,
      squareCentimeter: 0.0001,
      squareMillimeter: 0.000001,
      acre: 4046.8564224,
      squareFoot: 0.09290304,
      squareInch: 0.00064516
    },
    // 转换结果（所有单位）
    convertResults: {
      squareMeter: 0,
      mu: 0,
      hectare: 0,
      squareKilometer: 0,
      squareDecimeter: 0,
      squareCentimeter: 0,
      squareMillimeter: 0,
      acre: 0,
      squareFoot: 0,
      squareInch: 0
    }
  },
  "setup": function() {
    // 页面初始化：默认转换0值
    this.convertArea()
  },
  "actions": {
    "convertArea": function() {
      const { inputValue, sourceUnit, unitRate } = this.state
      // 1. 计算源单位对应的平方米总数
      const totalSquareMeter = inputValue * unitRate[sourceUnit]
      // 2. 转换为所有单位
      const results = {}
      for (const unit in unitRate) {
        results[unit] = totalSquareMeter / unitRate[unit]
      }
      // 3. 更新状态，驱动页面刷新
      this.state.convertResults = results
    }
  }
}