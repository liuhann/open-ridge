export default {
  name: "Lottery",
  state: {
    nameList: "",
    prizeCount: 1,
    scrollName: "等待开始抽奖",
    winnerList: "暂无中奖人员",
    // 按钮状态
    startBtnDisabled: false,
    pickBtnDisabled: true,
    // 名单数据
    originNames: [],
    remainNames: [],
    winNum: 0,
    // 定时器
    timer: null,
    isScrolling: false
  },
  computed: {},
  setup() {},
  actions: {
    // 解析名单、初始化数据
    initData() {
      const list = this.nameList.split(/\n/).filter(item => item.trim());
      this.originNames = list;
      this.remainNames = [...list];
      this.winNum = 0;
      this.winnerList = "暂无中奖人员";
    },

    // 启动姓名滚动
    startScroll() {
      this.initData();
      const total = this.originNames.length;
      const target = Math.min(this.prizeCount, total);

      if (total === 0) {
        alert("请先输入参与人员名单！");
        return;
      }
      if (target <= 0) {
        alert("奖品数量不能为0！");
        return;
      }

      this.isScrolling = true;
      // 切换按钮状态
      this.startBtnDisabled = true;
      this.pickBtnDisabled = false;

      // 持续滚动名单
      this.timer = setInterval(() => {
        const idx = Math.floor(Math.random() * this.remainNames.length);
        this.scrollName = this.remainNames[idx];
      }, 80);
    },

    // 单次抽取一位中奖人
    pickOne() {
      const total = this.originNames.length;
      const target = Math.min(this.prizeCount, total);
      if (this.winNum >= target) return;

      // 定格当前滚动的人员
      const luckyMan = this.scrollName;
      this.winNum++;

      // 拼接中奖列表
      if (this.winnerList === "暂无中奖人员") {
        this.winnerList = `第${this.winNum}位：${luckyMan}`;
      } else {
        this.winnerList += `\n第${this.winNum}位：${luckyMan}`;
      }

      // 移除已中奖人员，避免重复抽取
      const delIdx = this.remainNames.findIndex(item => item === luckyMan);
      if (delIdx > -1) {
        this.remainNames.splice(delIdx, 1);
      }

      // 抽满名额，停止滚动、禁用抽取按钮
      if (this.winNum >= target) {
        clearInterval(this.timer);
        this.isScrolling = false;
        this.pickBtnDisabled = true;
        alert("所有名额已抽取完毕！");
      }
    },

    // 重置全部状态
    resetLottery() {
      clearInterval(this.timer);
      this.nameList = "";
      this.prizeCount = 1;
      this.scrollName = "等待开始抽奖";
      this.winnerList = "暂无中奖人员";
      this.startBtnDisabled = false;
      this.pickBtnDisabled = true;
      this.originNames = [];
      this.remainNames = [];
      this.winNum = 0;
      this.isScrolling = false;
      this.timer = null;
    }
  }
};