export default {
  name: "Year2026Count",
  state: {
    // 基础日期
    today: "2026-06-17",
    yearStart: "2026-01-01",
    yearEnd: "2026-12-31",
    // 2026法定节假日（全天放假，不含调班补班）
    holidayList: [
      "2026-01-01",
      "2026-01-02",
      "2026-01-03",
      "2026-01-26",
      "2026-01-27",
      "2026-01-28",
      "2026-01-29",
      "2026-01-30",
      "2026-01-31",
      "2026-02-01",
      "2026-04-04",
      "2026-04-05",
      "2026-04-06",
      "2026-05-01",
      "2026-05-02",
      "2026-05-03",
      "2026-05-04",
      "2026-05-05",
      "2026-06-19",
      "2026-09-25",
      "2026-09-26",
      "2026-09-27",
      "2026-10-01",
      "2026-10-02",
      "2026-10-03",
      "2026-10-04",
      "2026-10-05",
      "2026-10-06",
      "2026-10-07"
    ],
    // 统计结果
    totalNaturalDays: 365,
    passedNaturalDays: 0,
    restNaturalDays: 0,

    totalWorkDays: 0,
    passedWorkDays: 0,
    restWorkDays: 0,

    workHourPerDay: 8,
    totalWorkHours: 0,
    passedWorkHours: 0,
    restWorkHours: 0,
    workHourPercent: 0,

    showDetail: true
  },
  setup() {
    this.calcYearData();
    // 每秒刷新日期计算
    setInterval(() => {
      this.calcYearData();
    }, 1000 * 60);
  },
  actions: {
    // 开关切换详情显示
    toggleDetail() {
      this.state.showDetail = !this.state.showDetail;
    },

    // 日期格式化 YYYY-MM-DD
    formatDate(date) {
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, "0");
      const d = String(date.getDate()).padStart(2, "0");
      return `${y}-${m}-${d}`;
    },

    // 判断是否周末/节假日
    isOffDay(dateStr) {
      const d = new Date(dateStr);
      const week = d.getDay();
      // 周六6 周日0
      if (week === 0 || week === 6) return true;
      // 法定节假日
      return this.state.holidayList.includes(dateStr);
    },

    // 计算两个日期之间所有日期数组
    getDateRange(startStr, endStr) {
      const list = [];
      let cur = new Date(startStr);
      const end = new Date(endStr);
      while (cur <= end) {
        list.push(this.formatDate(cur));
        cur.setDate(cur.getDate() + 1);
      }
      return list;
    },

    // 核心计算全年、已过、剩余自然日/工作日/工时
    calcYearData() {
      const s = this.state;
      const todayStr = s.today;
      const yearStart = s.yearStart;
      const yearEnd = s.yearEnd;

      // 全年所有日期
      const allYearDays = this.getDateRange(yearStart, yearEnd);
      // 已过完日期（不含今天）
      const passedDaysList = this.getDateRange(yearStart, todayStr).filter(d => d < todayStr);
      // 剩余日期（含今天到年末）
      const restDaysList = this.getDateRange(todayStr, yearEnd);

      // 自然日统计
      s.totalNaturalDays = allYearDays.length;
      s.passedNaturalDays = passedDaysList.length;
      s.restNaturalDays = restDaysList.length;

      // 全年工作日
      const allWorkDays = allYearDays.filter(d => !this.isOffDay(d));
      s.totalWorkDays = allWorkDays.length;
      // 已过工作日
      const passedWorkDays = passedDaysList.filter(d => !this.isOffDay(d));
      s.passedWorkDays = passedWorkDays.length;
      // 剩余工作日
      const restWorkDays = restDaysList.filter(d => !this.isOffDay(d));
      s.restWorkDays = restWorkDays.length;

      // 工时换算
      s.totalWorkHours = s.totalWorkDays * s.workHourPerDay;
      s.passedWorkHours = s.passedWorkDays * s.workHourPerDay;
      s.restWorkHours = s.restWorkDays * s.workHourPerDay;

      // 进度百分比
      s.workHourPercent = Number(((s.passedWorkHours / s.totalWorkHours) * 100).toFixed(2));
    }
  }
}